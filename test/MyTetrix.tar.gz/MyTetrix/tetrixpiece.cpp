/****************************************************************************
**
** Copyright (C) 2010 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
** Contact: Nokia Corporation (qt-info@nokia.com)
**
** This file is part of the examples of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:BSD$
** You may use this file under the terms of the BSD license as follows:
**
** "Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are
** met:
**   * Redistributions of source code must retain the above copyright
**     notice, this list of conditions and the following disclaimer.
**   * Redistributions in binary form must reproduce the above copyright
**     notice, this list of conditions and the following disclaimer in
**     the documentation and/or other materials provided with the
**     distribution.
**   * Neither the name of Nokia Corporation and its Subsidiary(-ies) nor
**     the names of its contributors may be used to endorse or promote
**     products derived from this software without specific prior written
**     permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
** "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
** LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
** A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
** OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
** SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
** LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
** DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
** THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
** (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
** OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."
** $QT_END_LICENSE$
**
****************************************************************************/

#include <QtCore>

#include <stdlib.h>
#include <QDebug>

#include "tetrixpiece.h"

//! [0]
void TetrixPiece::setRandomShape()
{
    setShape(TetrixShape(qrand() % 7 + 1));
}
//! [0]

//! [1]
void TetrixPiece::setShape(TetrixShape shape)
{
    //用一个三维数组来确定方块的形状
    static const int coordsTable[8][4][2] = {
        //这个表示没有
        { { 0, 0 },   { 0, 0 },   { 0, 0 },   { 0, 0 } },
        /*这个为 |_
                  |  形*/
        { { 0, -1 },  { 0, 0 },   { -1, 0 },  { -1, 1 } },
        /*这个为  _|
                |  形*/
        { { 0, -1 },  { 0, 0 },   { 1, 0 },   { 1, 1 } },
        /*这个为 |
                |  形*/
        { { 0, -1 },  { 0, 0 },   { 0, 1 },   { 0, 2 } },
        /*这个为  __|__  形*/
        { { -1, 0 },  { 0, 0 },   { 1, 0 },   { 0, 1 } },
        /*这个为  _
                |_|  形*/
        { { 0, 0 },   { 1, 0 },   { 0, 1 },   { 1, 1 } },
        /*这个为   |
                 _|  形*/
        { { -1, -1 }, { 0, -1 },  { 0, 0 },   { 0, 1 } },
        /*这个为   |
                  |_  形*/
        { { 1, -1 },  { 0, -1 },  { 0, 0 },   { 0, 1 } }
    };

    for (int i = 0; i < 4 ; i++) {
        for (int j = 0; j < 2; ++j)
            coords[i][j] = coordsTable[shape][i][j];
    }
    pieceShape = shape;
//! [1] //! [2]
}
//! [2]

//! [3]
int TetrixPiece::minX() const
{
    int min = coords[0][0];
    for (int i = 1; i < 4; ++i)
        min = qMin(min, coords[i][0]);
    return min;
}

int TetrixPiece::maxX() const
//! [3] //! [4]
{
    int max = coords[0][0];
    for (int i = 1; i < 4; ++i)
        max = qMax(max, coords[i][0]);
    return max;
}
//! [4]

//! [5]
int TetrixPiece::minY() const
{
    int min = coords[0][1];
    for (int i = 1; i < 4; ++i)
        min = qMin(min, coords[i][1]);
    return min;
}

int TetrixPiece::maxY() const
//! [5] //! [6]
{
    int max = coords[0][1];
    for (int i = 1; i < 4; ++i)
        max = qMax(max, coords[i][1]);
    return max;
}
//! [6]

//! [7]
TetrixPiece TetrixPiece::rotatedLeft() const
{
    //田字形不用变形
    if (pieceShape == SquareShape)
        return *this;

    TetrixPiece result;
    result.pieceShape = pieceShape;
    for (int i = 0; i < 4; ++i) {
        result.setX(i, y(i));
        result.setY(i, -x(i));
    }
//! [7]
    return result;
}



/*************************************************************************
* 函数名称： rotatedRight
* 功能描述： 这个是底层旋转方块旋转的功能函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明： 在这里做一个微调，因为每个方块的原型是用一个二维坐标来定义的，所以当变形之后，
*其会出现整个方块水平移位的现象，这是因为变形之后，最大x轴的值变化啦，所以我们在这里要做一个
*调整，注意直条形的不需调整，其变形之后x轴坐标的值不变化反倒不正常。
*出啦那个直条的俄罗斯方块外，正方形的方块不用变形，其他方块的变形都可以在
*一个3*3的9空格内变形完成。所以超超出这个范围的我们要进行微调让其不超过范围
***********可以参考文档中，对各种方块变形的调整的方案***************
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
//! [9]
TetrixPiece TetrixPiece::rotatedRight() const
{
    //田字形不用变形
    if (pieceShape == SquareShape)
        return *this;

    TetrixPiece result;
    result.pieceShape = this->pieceShape;

    //出直条外剩下的5个方块类型做调整，保证其变形后最大x轴的值不变，
    //这样才不会出现变形水平方向移位的现象
    if( pieceShape != LineShape )
    {
        //在这里进行变形
        for (int i = 0; i < 4; ++i)
        {
            result.setX(i, -y(i));
            result.setY(i, x(i));
        }
        //qDebug() << "the pieceShape is : " <<  pieceShape ;
        int maxX_Before_Roate = this->maxX() ;   //变换前的最大x轴值
        int maxX_After_Roate = result.maxX() ;   //变换后的最大x轴值
        //如果变换前的最大值大于变换后的最大值，则应向上移这个间隔，以变换前的为标准
        //如果变换前的最大值小于变换后的最大值，则应向下移这个间隔，以变换前的为标准
        //这个是要修正的偏移值，这个便宜值为正则向上微调，为负则向下微调
        int xOffset = maxX_Before_Roate - maxX_After_Roate ;
        if( xOffset )   //不为0则是要调整
        {
            for (int i = 0; i < 4; ++i)
            {
                int xCoord = result.x( i ) ;    //这个是偏移后的每个点x轴值
                result.setX(i, xCoord + xOffset );   //进行调整
            }
        }
    }
    else      //单独对直条进行变形
    {
        for (int i = 0; i < 4; ++i)
        {
            //直条俄罗斯方块变形就是x轴与y轴的值对调就可以啦
            result.setX(i, y(i));
            result.setY(i, x(i));
        }
    }
//! [9]
    return result;
}
