#ifndef GAMEHIGHWINITEM_H
#define GAMEHIGHWINITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>

#include "GameButtonItem.h"
#include "GameGraphicsScene.h"

#include "globaldefines.h"
/**************************************************************************
 *                        常量                                            *
 **************************************************************************/

/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/

/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/

/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/

class GameHighWinItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:
    /*
    通过这个当前箭头所对应的序号的值
    比如说
    0---->开始游戏
    1---->游戏介绍
    。。。。。。
    在NumAndPointerHash表中查找相应的Item的指针的值
    */
    //在这里是用户点击的时候发送这个信号出去，返回到游戏的首页去
    void backToSecondLay( int index ) ;
public:
    GameHighWinItem(const QString &imageName ,QGraphicsItem *parent=0) ;
    ~GameHighWinItem() ;

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void setGameScene( GameGraphicsScene *gameScene,
          const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;

private:
    QString myImageName ;        //用来承载构造函数的imageName参数的
    GameGraphicsScene *m_Scene ;    //用来承载游戏场景的变量
    QPixmap highWinPixmap ;      //图片

    GameButtonItem *backButton ; //返回按钮
    //添加返回按钮
    void addBackButton( const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash );

private slots:
    void clickOnBackButton() ;      //点击按钮的槽函数

protected:
    void mousePressEvent ( QGraphicsSceneMouseEvent * event ) ;
    void mouseReleaseEvent ( QGraphicsSceneMouseEvent * event ) ;

};
#endif // GAMEHIGHWINITEM_H
