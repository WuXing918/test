#include "GameArrowItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameArrowItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameArrowItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameArrowItem::GameArrowItem(const QString &imageName, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent),myImageName(imageName)
    ,isCovered(false)
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    //设置其可以接收焦点
    this->setFlags( QGraphicsItem::ItemIsFocusable );
    this->setFocus() ;     //设置其初始为焦点
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );
}



/***********************************************************************
* 函数名称： ~GameArrowItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameArrowItem::~GameArrowItem()
{

}

/**************************************************************************
* 函数名称： setGameScene
* 功能描述： 设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
*          同时获得在NameAndPointHash表中的坐标的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameArrowItem::setGameScene(GameGraphicsScene *gameScene, const NameAndImageHash
                                  &nameImagehash, const NameAndPointHash &namePointHash)
{
    QImage *image ;
    m_Scene = gameScene ;
    //连接改变箭头Item的遮蔽状态的槽函数
    connect(gameScene,SIGNAL(changeCoveredStateSignal(bool)),
            this,SLOT(changeCoveredStateSlot(bool)));
    //转发一些对方块进行移动的信号
    connect(this,SIGNAL(leftKeyDownSignal()),gameScene,SIGNAL(leftKeyDownSignal())) ;
    connect(this,SIGNAL(rightKeyDownSignal()),gameScene,SIGNAL(rightKeyDownSignal())) ;
    connect(this,SIGNAL(upKeyDownSignal()),gameScene,SIGNAL(upKeyDownSignal())) ;
    connect(this,SIGNAL(downKeyDownSignal()),gameScene,SIGNAL(downKeyDownSignal())) ;
    connect(this,SIGNAL(spaceKeyDownSignal()),gameScene,SIGNAL(spaceKeyDownSignal())) ;
    //转发暂停游戏的信号
    connect(this,SIGNAL(pauseKeyDownSignal()),gameScene,SIGNAL(pauseKeyDownSignal())) ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        image = nameImagehash.value( myImageName ) ;
        arrowPixmap = QPixmap::fromImage( *image ) ;

        this->setPixmap( arrowPixmap );
        m_Scene->addItem( this ) ;
        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        if( namePointHash.contains( myImageName ) )
        {
            firstPos = namePointHash.value( myImageName ) ;
            initPointList() ;     //初始话PointList列表
            this->setPos( firstPos );
        }

    }
}



/**************************************************************************
* 函数名称： initPointList
* 功能描述： 初始话PointList列表
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameArrowItem::initPointList()
{
    int x = firstPos.x() ;
    int y = firstPos.y() ;
    //因为算上初始坐标总共5个位置可以移动
    //因为两个坐标之间只是在y轴上相差90
    //这个90是通过ModeWin中那个5个Button的y轴间隔来确定的
    for(int i=0;i<5;i++)
    {
        pointList.append( QPoint( x,y+90*i ) ) ;
    }

}


/**************************************************************************
* 函数名称： setPointListIndex
* 功能描述： 通过一个来随机设置箭头的坐标，这个是当鼠标光标在右边的5个ModeWin的Button移动是
*          改变箭头坐标的接口
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：注意index的值只能是0，1，2，3，4
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameArrowItem::setPointListIndex(int index)
{
    //因为5个坐标在列表中的序号是0，1，2，3，4所以其他范围的就错误
    if( index < 0 && index > 4 )
    {
        DEBUGP( "index in PointList error !" ) ;
        return ;
    }
    else
    {
        int x = this->pos().x() ;
        int y = this->pos().y() ;
        QPoint nowPos( x,y) ;      //当前的坐标值
        //DEBUGP( nowPos ) ;
        /*
        如果当前坐标就是在光标所在的Button对应的坐标点上，
        则退出不改变坐标，避免引起闪烁的效果
        */
        //DEBUGP( pointList ) ;
        //DEBUGP( pointList.indexOf( nowPos ) ) ;
        if( pointList.indexOf( nowPos ) == index )
        {
            return ;
        }
        else
        {
            //否则改变坐标
            //DEBUGP( pointList.at( index ) ) ;
            this->setPos( pointList.at( index ) );
        }
    }
}

/**************************************************************************
* 函数名称： moveArrowUp
* 功能描述： 向上移动箭头
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameArrowItem::moveArrowUp()
{
    int x = this->pos().x() ;
    int y = this->pos().y() ;
    QPoint nowPos( x,y) ;      //当前的坐标值
    int index = pointList.indexOf( nowPos ) ;  //得到当前坐标所在的序号
    //如果是在最上面则移动到最下面去
    if( !index )
    {
        setPointListIndex( 4 );
    }
    else
    {
        setPointListIndex( index -1 );
    }
}

/**************************************************************************
* 函数名称： moveArrowDown
* 功能描述： 向下移动箭头
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameArrowItem::moveArrowDown()
{
    int x = this->pos().x() ;
    int y = this->pos().y() ;
    QPoint nowPos( x,y ) ;      //当前的坐标值
    int index = pointList.indexOf( nowPos ) ;  //得到当前坐标所在的序号
    //如果是在最下面则移动到最上面去
    if( index == 4  )
    {
        setPointListIndex( 0 );
    }
    else
    {
        setPointListIndex( index + 1 );
    }
}

/**************************************************************************
* 函数名称： getNowIndexInPointList
* 功能描述： 得到箭头图片所在位置的坐标在PointList中的索引值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
inline int GameArrowItem::getNowIndexInPointList()
{
    QPoint nowPos( this->pos().x(),this->pos().y() ) ;     //当前的坐标值
    return pointList.indexOf( nowPos ) ;  //得到当前坐标所在的序号
}

/**************************************************************************
* 函数名称： changeCoveredStateSlot
* 功能描述： 改变当前的这个箭头Item是否被遮蔽的状态的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameArrowItem::changeCoveredStateSlot(bool state)
{
    isCovered = state ;
    //DEBUGP( "changeCoveredStateSlot" )
}

/**************************************************************************
* 函数名称： keyPressEvent
* 功能描述： 重在按键事件，让其处理向上与向下移动箭头
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：在这里通过按下回车发送信号打开箭头所对应的选项
*          用户按Esc键返回到第二层，也就是游戏界面首页
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameArrowItem::keyPressEvent(QKeyEvent *e)
{
    if(e->type() == QEvent::KeyPress)
    {
       QKeyEvent* event = static_cast<QKeyEvent*>(e);
       //当前的箭头的Item是否被遮蔽，按快捷键会有不同的操作
       if( isCovered )
       {
           //当前的箭头的Item是被遮蔽时，就会发送信号来操作俄罗斯方块，不过按Esc仍然会返回
           switch (event->key())
           {
                case Qt::Key_Escape:
                    emit backToSecondLay( getNowIndexInPointList() );
                    break ;
                case Qt::Key_Down:
                    emit downKeyDownSignal();
                    break;
                case Qt::Key_Up:
                    emit upKeyDownSignal();
                    break;
                case Qt::Key_Left:
                    emit leftKeyDownSignal();
                    break ;
                case Qt::Key_Right:
                    emit rightKeyDownSignal();
                    break ;
                case Qt::Key_Space:
                    emit spaceKeyDownSignal();
                    break ;
               case Qt::Key_P:       //按下p键发送暂停游戏的信号
                   emit pauseKeyDownSignal();
                   break ;
                default:
                    QGraphicsItem::keyPressEvent(event);
            }
       }
       else
       {
           switch (event->key())
           {
                case Qt::Key_Escape:
                    emit backToSecondLay( getNowIndexInPointList() );
                    break ;
                case Qt::Key_Down:
                    moveArrowDown();
                    break;
                case Qt::Key_Up:
                    moveArrowUp() ;
                    break;
                case Qt::Key_Enter:
                case Qt::Key_Return:
                    emit enterIntoButton( getNowIndexInPointList() );
                    break ;
                default:
                    QGraphicsItem::keyPressEvent(event);
           }
       }

   }
}

/**************************************************************************
* 函数名称： focusOutEvent
* 功能描述： 重载焦点移除事件，重新让其获得焦点
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameArrowItem::focusOutEvent(QFocusEvent *event)
{
    Q_UNUSED( event ) ;
    this->setFocus();
}

