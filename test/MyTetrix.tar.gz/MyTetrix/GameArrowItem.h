#ifndef GAMEARROWITEM_H
#define GAMEARROWITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QPoint>
#include <QList>
#include <QKeyEvent>

#include "globaldefines.h"
#include "GameGraphicsScene.h"
/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/
//这是定义的一个简单的坐标的列表
typedef QList< QPoint >  PointList ;

/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这个类是定义的一个箭头的类，因为有一些特殊的事件要重载，所以单独放这里做一个类
*/
class GameArrowItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:
    /*
    这个是根据箭头所在的当前位置的索引来进入到对应的button按钮
    比如说
    0---->开始游戏
    1---->游戏介绍
    。。。。。。
    */
    void enterIntoButton( int index ) ;
    //用户按Esc键返回到第二层，返回游戏首页的信号
    /*
    通过这个当前箭头所对应的序号的值
    比如说
    0---->开始游戏
    1---->游戏介绍
    。。。。。。
    在NumAndPointerHash表中查找相应的Item的指针的值
    */
    void backToSecondLay( int index ) ;

    /*******************这是定义的一些对方块进行移动变形操作的信号*******************/
    void leftKeyDownSignal() ;
    void rightKeyDownSignal() ;
    void upKeyDownSignal() ;
    void downKeyDownSignal() ;
    void spaceKeyDownSignal() ;
    void pauseKeyDownSignal() ;             //按下p键的暂停游戏的信号

public:
    GameArrowItem(const QString &imageName ,QGraphicsItem *parent=0) ;
    ~GameArrowItem() ;

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void setGameScene( GameGraphicsScene *gameScene,
          const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;

private:

    QString myImageName ;        //用来承载构造函数的imageName参数的
    GameGraphicsScene *m_Scene ;    //用来承载游戏场景的变量
    QPixmap arrowPixmap ;             //箭头图片
    QPoint firstPos ;           //这个两表示箭头的初始坐标值
    //这个是一个箭头可到的位置的坐标的集合。即箭头只能在这个列表中的值来移动
    PointList pointList ;
    void initPointList( ) ;     //初始话PointList列表

    void moveArrowUp( ) ;               //向上移动箭头
    void moveArrowDown( ) ;             //向下移动箭头
    //得到箭头图片所在位置的坐标在PointList中的索引值
    inline int getNowIndexInPointList() ;

    /*************************这个是为啦处理快捷键复用的情况************************/
    /*
    这个是表示当前的这个箭头Item是否被遮蔽，因为当选择一个按钮之后会弹出
    一个大的Item遮蔽这个小的箭头这个时候快捷键的操作会改变
    */
    bool isCovered ;        //默认情况为false，表示没有被遮蔽

private slots:
    /*
    通过一个来随机设置箭头的坐标，这个是当鼠标光标在右边的5个ModeWin的Button移动是
    改变箭头坐标的接口
    */
    void setPointListIndex( int index ) ;

    //改变当前的这个箭头Item是否被遮蔽的状态的槽函数
    void changeCoveredStateSlot( bool state ) ;

protected:
    void keyPressEvent ( QKeyEvent * e ) ;
    void focusOutEvent ( QFocusEvent * event ) ;
};

#endif // GAMEARROWITEM_H
