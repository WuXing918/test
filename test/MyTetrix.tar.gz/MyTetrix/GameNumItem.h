#ifndef GAMENUMITEM_H
#define GAMENUMITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QPainter>


#include "globaldefines.h"
#include "GameGraphicsScene.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/
//这个是定义的三种数字的类型。
enum GameNumType { SpeedNum , RowNum , ScoreNum } ;

/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这个是一个数字的类，用于显示速度，行数，分数。放在第四层
从配置文件中读出的坐标值是速度数字的坐标值，其他数字的坐标值根据类型加上相应的间隔
*/
class GameNumItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    GameNumItem(const QString &imageName,GameNumType type,QGraphicsItem *parent=0);
    ~GameNumItem();

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void initPosAndImage( const NameAndImageHash &nameImagehash,
                          const NameAndPointHash &namePointHash ) ;

    //这个是对外留出的一个接口，通过这个接口来显示不同的数字的图片，一定是整形
    void setNumPixmap( QString numString ) ;
private:
    GameNumType numType ;        //这个是用来承载数字的类型的变量
    QString myImageName ;        //用来承载构造函数的imageName参数的
    QPixmap numPixmap ;          //图片
    int perWidth ;               //这个是记录图片的宽与高的两个变量
    int perHeight ;              //注意这里记录的是一个状态的图片的宽与高，不是整张大图的宽与高

    QPoint firstPos ;           //这个表示数字的图标的初始坐标值

    //根据数字的种类和配置文件中读取的初始坐标来确定数字的初始位置坐标
    QPoint getFirstPosByNumType( GameNumType numtype,const QPoint &posFormFile ) ;

    /*
    从这numPixmap一整张大图中得到相应的数字的的图片的函数
    在这里只是得到的0到9的每个数字对应的图片
    */
    inline QPixmap getDigitalPixmap( int num ) ;
    //这个是绘制非1位数字的图片时，用到的绘制函数
    void drawNumStringPixmap( QPainter &painter,QString numString ) ;

};


#endif // GAMENUMITEM_H
