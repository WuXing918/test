#include "GameLogoImageItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameLogoImageItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameLogoImageItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/


GameLogoImageItem::GameLogoImageItem( QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent)
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    //初始化这个图片，格式要指定为这种格式，否则无法在其上进行绘制操作
    //这里指定图片的大小为800*600，因为只有logo时才用到这个，所以就这么写死在这里
    resultImage = QImage( QSize(800,600) ,QImage::Format_ARGB32_Premultiplied );

    timeLine = new QTimeLine(LOGOIMAGE_TIMELINE,this);      //一秒的logo渐变时间

    connect(timeLine,SIGNAL(frameChanged(int)),this,SLOT(showAnimationtoMove(int)));
    connect(timeLine,SIGNAL(finished()),this,SLOT(timeLineFinished()));

}



/***********************************************************************
* 函数名称： ~GameLogoImageItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameLogoImageItem::~GameLogoImageItem()
{

}

/**************************************************************************
* 函数名称： setGameScene
* 功能描述： 设置场景
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameLogoImageItem::setGameScene(GameGraphicsScene *gameScene, const NameAndImageHash &hash)
{
    QImage *logoImage1 = NULL ;
    QImage *logoImage2 = NULL ;

    m_Scene = gameScene ;
    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( hash.contains( LOGO_1 ) && hash.contains( LOGO_2 ) )
    {
        logoImage1 = hash.value(LOGO_1) ;
        logoImage2 = hash.value(LOGO_2) ;
    }

    //从QImage类型转换到QPixmap
    logoPixmap1 = QPixmap::fromImage( *logoImage1 );
    /*
    logoPixmap2 = &QPixmap::fromImage( *logoImage1 );
    这样写只所以不行，是因为其是栈空间，栈空间不能长期保存
    */
    logoPixmap2 = QPixmap::fromImage( *logoImage2 );

    this->setPixmap( logoPixmap1 );   //首先显示纯白色
    this->setZValue(0.0);          //让这两个logo图标在最底层
    m_Scene->addItem( this );      //添加到场景去

    timeLineStart() ;              //在这里开始显示logo动画效果
}


/**************************************************************************
* 函数名称： timeLineStart
* 功能描述： 开始显示logo渐变的动画效果
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameLogoImageItem::timeLineStart()
{
    if (timeLine->state() == QTimeLine::NotRunning)
    {
        timeLine->setFrameRange(0, 100);
        timeLine->setCurveShape(QTimeLine::LinearCurve);
        timeLine->setUpdateInterval(60);     //每60毫秒改变一次
        timeLine->start();
    }
}

/**************************************************************************
* 函数名称： getFadeOutImage
* 功能描述： 得到一个渐显效果的图片
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：所谓渐显效果，就是在图片上加一层纯白色，
*         然后改变这个纯白色的alpha通道的值，来达到整个图片渐显的效果
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameLogoImageItem::getFadeOutImage(int alpha)
{
    QPainter painter(&resultImage);
    painter.setCompositionMode(QPainter::CompositionMode_Source);
    painter.fillRect(resultImage.rect(), Qt::transparent);
    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    painter.drawPixmap(0, 0, logoPixmap2 );
    painter.setCompositionMode(QPainter::CompositionMode_SourceOver);
    //用纯白色来填充到图片上，改变纯白色的alpha通道值
    painter.fillRect(resultImage.rect(), QColor(255,255,255,alpha));
    painter.end();

    this->setPixmap( QPixmap::fromImage( resultImage ) );
}

/**************************************************************************
* 函数名称： showAnimationtoMove
* 功能描述： 动画效果
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameLogoImageItem::showAnimationtoMove(int frame)
{
    qreal alpha ;
    if( frame )
    {
        alpha = (255.0 / 100.0) * frame ;
    }
    else
    {
        alpha = 0 ;
    }
    //DEBUGP( alpha ) ;
    getFadeOutImage( 255 -(int)alpha  ) ;
}

/**************************************************************************
* 函数名称： timeLineFinished
* 功能描述： firsttimeLine的动画时间结束
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameLogoImageItem::timeLineFinished()
{
    this->setPixmap( logoPixmap2 );
    //发送信号给主Widget显示背景层图片
    emit addGameBackGroundItem() ;
}

