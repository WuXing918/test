#ifndef TETRIXBOARD_H
#define TETRIXBOARD_H

#include <QPixmap>
#include <QImage>
#include <QPainter>
#include <QObject>
#include <QTime>
#include <QTimer>
#include <QList>
#include <QIcon>
#include <QSize>

#include "tetrixpiece.h"
#include "globaldefines.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/
//这两个表示水平方向与垂直方向上的方块数
#define    PIECE_NUM_IN_VERTICAL         20
#define    PIECE_NUM_IN_HORIZONTAL       10

/*
这个是定义的每个小方块的宽与高，其实是一个正方形，只要定义一个边长即可，
但是因为最后要做一个全屏的功能，怕到时全屏时，不是宽度与高度等比变换
，这里只是这么宏定义着，以后会修改的。因为现在还没有加载图片，可能
会让底层的图片来确定每个小方块的宽与高，这样灵活些。
*/
#define   PIECE_WIDTH         28
#define   PIECE_HEIGHT        28

/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/
//这个是定义的一个整形的列表
typedef   QList< int >       IntList ;

/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
*    这是一个简单类，没有想基于QWidget基本的控件，因为不需要在基本的控件中显示，最后要
*    通过QGraphicsPixmapItem这个类来显示的，所以这里只是通过这个类，得到所要显示的一组
*    pixmap就可！可以说是一个简单的数据处理的类，只是为拉使用Qt的信号与槽机制而基于
*    QObject类
*/

class TerixBoard : public QObject
{
    Q_OBJECT
signals:
    //这个是更新下一块滑块的图片的信号
    void updateNextPiecePixmapSignal() ;
    //这个是更新游戏区域的信号
    void updateGameAreaPixmapSignal() ;
    //这个是更新消除的速度的信号
    void updateSpeedNumSignal( int speedNum );
    //这个是更新消除的总行数的信号
    void updateNumRowsRemovedSignal( int rowNum ) ;
    //这个是更新消除的用户分数的信号
    void updateScoreNumSignal( int score ) ;
    //这个是发送显示爆炸特效的信号
    void showBombEffectSignal( int pos ) ;
    //这个是发送的游戏结束的信号
    void gameOverSignal() ;

    /***************************************************************
      这下面是当滑块落到底部和消除满行时的声音特效的控制信号
    ***************************************************************/
    //这个是满行时产生爆炸声音的信号
    void crushAudioSoundSignal() ;
    //这个是当滑块落到最低点时撞击的声音的信号
    void fellAudioSoundSignal() ;
public:
    TerixBoard( int level ,const NameAndImageHash &nameImagehash) ;
    ~TerixBoard( ) ;

    /*****************下面是留出的一些接口，供外界来调用控制游戏相关设置*****************/
    //这个是对外的两个获得游戏区域的图片的接口函数
    QPixmap getGameAreaPixmap() ;
    QPixmap getNextPiecePixmap() ;

    /***************************************************************
      这下面是一些对俄罗斯方块变形操作的接口函数
    ***************************************************************/
    void dropDownFun();        //直接扔到最底部
    void oneLineDownFun();     //向下移动一行
    void moveToLeftFun();      //向左移动
    void moveToRightFun();     //向右移动
    void rotateFun();          //变形操作，每次逆时针旋转90度
    void pauseKeyDownFun() ;   //按下p键的暂停游戏的接口函数

    void restartGame( ) ;       //重新开始游戏

    void gameDeactivateFun() ;  //这个是当游戏不为当前活动窗口时的功能函数

    /***************************************************************
      下面这个两个是留出的得到游戏当前的是否暂停与是否结束的状态的接口函数
    ***************************************************************/
    bool getGamePauseStateFun();             //得到游戏当前是否暂停的状态的函数接口
    bool getGameGameOverStateFun();          //得到游戏当前是否结束的状态的函数接口
private:

    /*********************这下面是两个最终要得到的实时更新的图片*******************/
    QPixmap gameAreaPixmap ;   //游戏区域的图片，游戏区域为下落的位置。
    QPixmap nextPiecePixmap ;  //表示下一块方块的图片

    //初始话所有的图片相关的变量
    void init_All_Pixmaps( const NameAndImageHash &nameImagehash ) ;

    void gameStart( ) ;         //开始游戏

    void gameOver( ) ;          //游戏结束
    void setGameAreaPixmapDisabled() ;      //这个是设置游戏区域的图片为灰色

    void drawGameAreaPixmap( ) ;    //这个是绘制游戏区域的图片的函数
    void drawNextPiecePixmap( ) ;   //这个是绘制下一个方块的图片的函数
    /*
    这个函数是绘制每一个小方块的函数，根据每一个小方块所属的类型
    以及其坐标来绘制不同颜色的小方块
    */
    void drawSquare(QPainter &painter, int x, int y, TetrixShape shape);

    /*这个是一个计时器，根据当前的关数不同来设定不同的更新时间，进而改变下降速度*/
    QTimer *timer ;

    /***********************这是一些标示游戏状态的变量***************************/
    bool isStarted ;        //游戏是否开始
    bool isPaused ;         //游戏是否暂停
    bool isGameOver ;       //游戏是否结束，默认情况下都是为false

    /***********************这是一些标示当前一些信息的变量***************************/
    //当前的速度，用对应的关数来表示，如第1关，则速度表示为01，依次类推
    //其实就是指定关数
    int  speedNum  ;
    int  intervalTime ;     //这个是根据不同的关数来设定的这个计时器的更新间隔时间
    int  numRowsRemoved ;   //这个是消除的总行数的记录
    //根据满行数来统计消除的总行数
    void computeNumRowsRemoved( int fullRowsNum ) ;
    /*
    统计分数的时候有个规则，就是一次消除1行得10分，一次消除2行得30分，一次消除3行得50分，
    一次消除4行得80分。一次最多也只能消除4行。
    */
    int  scoreNum ;         //这个是用户所得总分的一个记录
    //根据满行数来统计总的得分，得分会有一个规则的按照得分规则进行统计
    void computeScoreNum( int fullRowsNum ) ;
    int levelScoreNum ;     //这个是表示的在当前这个关中的得分
    //这个是根据目前的这关中得分情况来判断是否升级，提高方块下降的速度，增加难度
    void changeSpeedNumByScore( int levelscoreNum ) ;
    //通过board坐标系中的y坐标的值，计算出在GameAreaItem中对应的坐标值
    void getPosByPieceYCoord( int yCoord ) ;

    TetrixPiece curPiece;   //这个是表示当前的滑块
    TetrixPiece nextPiece;  //这个是表示下一个要出来的滑块
    //这个是由滑块类型组成的数组
    TetrixShape board[ PIECE_NUM_IN_HORIZONTAL * PIECE_NUM_IN_VERTICAL ];

    //这个是根据不同的关数来设定的这个计时器的更新间隔时间的函数
    int getIntervalTime( int level ) ;

    void clearBoard() ;     //初始化时清除board上的所有方块

    void createNewPiece() ; //创建新的方块
    /*
    这两个是标示当前一个方块的坐标，注意这个坐标是以上面的board数组组成的一个坐标系，
    在后面函数里面将会有详细的说明
    */
    int cur_X_Coord ;
    int cur_Y_Coord ;

    /*
    这个是试着移动的函数，通过结果判断是否成功，如果成功则返回true，否则返回false，
    成功则在游戏的画布上移动这个方块，否则不移动。
    */
    bool tryMove(const TetrixPiece &newPiece, int newX, int newY) ;
    //因为在游戏区域左右两边的滑块不能变形，用这个函数做一个微调，让其变形成功
    void adjustForRotateFun() ;

    //通过这个函数可以知道这个小方块组成的坐标系中的点是哪种方块类型
    //注意这个是放回引用类型，这个函数可以做左值
    TetrixShape &shapeAt(int x, int y) { return board[(y * PIECE_NUM_IN_HORIZONTAL) + x]; }

    void removeFullLines( ) ;      //删除其中的满行

    /*
    这个是当一个滑块落到最底部之后的处理函数。注意这个最底部是接触到下面已经存
    在的滑块或者到底游戏区域的最底部
    */
    void pieceDroppedToBottom();

    /******************这个位置是整合界面与功能的一些相关东西*****************/
    //这个是对应的定义的8种不同的图片分别对应8种不同的方块类型
    QPixmap blankPixmap ;
    QPixmap onePixmap ;
    QPixmap twoPixmap ;
    QPixmap threePixmap ;
    QPixmap fourPixmap ;
    QPixmap fivePixmap ;
    QPixmap sixPixmap ;
    QPixmap sevenPixmap ;

private slots:
    void timeoutSlot( ) ;  //这个是一个计时器时间结束信号的处理的槽函数


};



#endif // TETRIXBOARD_H
