#include "GameOptionItem.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameOptionItem实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameOptionItem
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameOptionItem::GameOptionItem(const QString &imageName, int musicVolume, int audioVolume, bool fullScreen, QGraphicsItem *parent)
    :QGraphicsPixmapItem(parent),myImageName(imageName)
    ,myMusicVolume(musicVolume),myAudioVolume(audioVolume)
    ,myFullScreen(fullScreen)
{
    this->setCacheMode(QGraphicsItem::ItemCoordinateCache);
    this->setShapeMode( QGraphicsPixmapItem::BoundingRectShape );

    /*
    在这里得设置接收鼠标悬挂事件，不然的话其就传到下层处理，
    就可能会改变小箭头的位置，而无法返回
    在这里纠结啦很长时间，还是要看文档，qt的文档确实很好的
    */
    this->setAcceptHoverEvents( true );
}



/***********************************************************************
* 函数名称： ~GameOptionItem()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameOptionItem::~GameOptionItem()
{

}

/**************************************************************************
* 函数名称： setGameScene
* 功能描述： 设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
*          同时获得在NameAndPointHash表中的坐标的值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数，把场景的指针传到这里，
*         这样的话所有的操作就可以在类中完成，使得模块化的思想更明显
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameOptionItem::setGameScene(GameGraphicsScene *gameScene, const NameAndImageHash
                                  &nameImagehash, const NameAndPointHash &namePointHash)
{
    QImage *image ;
    m_Scene = gameScene ;
    //转发改变音乐与音效音量大小的信号到场景中去
    connect(this,SIGNAL(changeVolumeSignal(int,int)),gameScene,SIGNAL(changeVolumeSignal(int,int))) ;

    //这个是为啦程序更加健壮，考虑如果添加到hash表中的错误
    if( nameImagehash.contains( myImageName ) )
    {
        image = nameImagehash.value( myImageName ) ;
        optionPixmap = QPixmap::fromImage( *image ) ;

        this->setPixmap( optionPixmap );
        m_Scene->addItem( this ) ;
        //通过NameAndPointHash表中查找到这个图片初始位置的坐标值
        if( namePointHash.contains( myImageName ) )
        {
            this->setPos( namePointHash.value( myImageName ) );
        }

        //初始化两个调节音量大小的Item
        initSpinKeyItem( nameImagehash,namePointHash) ;
    }
}

/**************************************************************************
* 函数名称： setConfigureFile
* 功能描述： 用来承载配置文件的指针的变量
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：通过这个函数把配置文件传到这里进行处理，之后写配置文件就在这里进行
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameOptionItem::setConfigureFile(QSettings *configIni)
{
    m_ConfigIni = configIni ;
}
/**************************************************************************
* 函数名称： initSpinKeyItem
* 功能描述： 初始化两个调节音量大小的Item
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameOptionItem::initSpinKeyItem(const NameAndImageHash &nameImagehash, const NameAndPointHash &namePointHash)
{
    //其作为子Item来显示
    //DEBUGP( myMusicVolume  ) ;
    musicKeyItem = new GameSpinKeyItem( OPTIONWIN_KEY,myMusicVolume,true,this ) ;
    musicKeyItem->initPosAndImage( nameImagehash,namePointHash );
    //DEBUGP( myAudioVolume  ) ;
    audioKeyItem = new GameSpinKeyItem( OPTIONWIN_KEY,myAudioVolume,false,this ) ;
    audioKeyItem->initPosAndImage( nameImagehash,namePointHash );
    //初始化全屏选择的Item
    //DEBUGP( myFullScreen  ) ;
    //DEBUGP( nameImagehash  ) ;
    checkItem = new FullScreenCheckItem( OPTIONWIN_CHECKBOX1,myFullScreen,this) ;
    checkItem->initPosAndImage( nameImagehash,namePointHash );
    //ok按钮Item
    okButton = new GameButtonItem( OPTIONWIN_OK ,this ) ;
    connect(okButton,SIGNAL(buttonClick()),this,SLOT(clickOnOkButtonSlot())) ;
    okButton->initPosAndImage( nameImagehash,namePointHash );
    //cancel按钮Item
    cancelButton = new GameButtonItem( OPTIONWIN_CANCEL ,this ) ;
    connect(cancelButton,SIGNAL(buttonClick()),
            this,SLOT(clickOnCancelButtonSlot())) ;
    cancelButton->initPosAndImage( nameImagehash,namePointHash );
}

/**************************************************************************
* 函数名称： setVolumeValueToFile
* 功能描述： 把音量的值写到配置文件中去
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
inline void GameOptionItem::setVolumeValueToFile(QString groupname, QString A_valueString, int volume)
{
    m_ConfigIni->beginGroup( groupname );
    m_ConfigIni->setIniCodec( "UTF-8" );
    m_ConfigIni->setValue( A_valueString ,volume ) ;
    m_ConfigIni->endGroup();
}


/**************************************************************************
* 函数名称： setFullScreenValueToFile
* 功能描述： 把是否全屏的值写到配置文件中去
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
inline void GameOptionItem::setFullScreenValueToFile(QString groupname, QString A_valueString, bool fullscreen)
{
    m_ConfigIni->beginGroup( groupname );
    m_ConfigIni->setIniCodec( "UTF-8" );
    m_ConfigIni->setValue( A_valueString ,fullscreen ) ;
    m_ConfigIni->endGroup();
}


/**************************************************************************
* 函数名称： clickOnOkButtonSlot
* 功能描述： 这个是点击ok按钮的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameOptionItem::clickOnOkButtonSlot()
{
    bool fullScreen = checkItem->getCheckItemState() ;
    //保存是否全屏的选项
    setFullScreenValueToFile( GROUPNAME_SETTINGS,SETTINGS_FULLSCREEN,fullScreen) ;
    int musicVolume = musicKeyItem->getNowVolume() ;
    //保存音乐的声音的大小
    setVolumeValueToFile( GROUPNAME_SETTINGS,SETTINGS_MUSIC,musicVolume );
    int audioVolume = audioKeyItem->getNowVolume() ;
    //保存音效的声音的大小
    setVolumeValueToFile( GROUPNAME_SETTINGS,SETTINGS_AUDIO,audioVolume );
    //点击确定按钮，发送的改变游戏音乐与音效音量大小的信号
    emit changeVolumeSignal( musicVolume,audioVolume );
    //注意这里的参数要与NumAndPointerHash中的对应，否则会出现错误
    emit backToSecondLay( 2 ) ;
}

/**************************************************************************
* 函数名称： clickOnCancelButtonSlot
* 功能描述： 这个是点击cancel按钮的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameOptionItem::clickOnCancelButtonSlot()
{
    //取消则不保存当前的配置选项
    //注意这里的参数要与NumAndPointerHash中的对应，否则会出现错误
    emit backToSecondLay( 2 ) ;
}
/**************************************************************************
* 函数名称： mousePressEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameOptionItem::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED( event ) ;
}

/**************************************************************************
* 函数名称： mouseReleaseEvent
* 功能描述：
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameOptionItem::mouseReleaseEvent(QGraphicsSceneMouseEvent *event)
{
    Q_UNUSED( event ) ;
}
