#ifndef FULLSCREENCHECKITEM_H
#define FULLSCREENCHECKITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QVariant>


#include "globaldefines.h"
#include "GameGraphicsScene.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/

/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这个是一个用户选择全屏的checkBox的类
*/
class FullScreenCheckItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    FullScreenCheckItem( const QString &imageName,
                         bool checked = false ,QGraphicsItem *parent=0) ;
    ~FullScreenCheckItem() ;

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void initPosAndImage( const NameAndImageHash &nameImagehash,
                          const NameAndPointHash &namePointHash ) ;

    //得到当前的状态，表示是否被选择
    bool getCheckItemState() ;
private:
    //由这个变量来表示其状态
    bool checkState ;           //用来承载构造函数的checked参数的
    QString myImageName ;      //用来承载构造函数的imageName参数的
    //两个状态所对应的不同的图片
    QPixmap checknotPixmap ;      //图片
    QPixmap checkedPixmap ;       //图片


    //设置状态
    void setCheckItemState( bool checked ) ;

protected:
    void mousePressEvent ( QGraphicsSceneMouseEvent * event ) ;
    void mouseReleaseEvent ( QGraphicsSceneMouseEvent * event ) ;
};

#endif // FULLSCREENCHECKITEM_H
