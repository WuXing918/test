#ifndef GAMEBACKGROUNDITEM_H
#define GAMEBACKGROUNDITEM_H

#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>


#include "GameGraphicsScene.h"
#include "globaldefines.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/


/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这个游戏背景是整个游戏软件的最底层，整个软件共分为6层，可以参看目录下的游戏设计的整体分层思想
这一层，进入游戏首页后的背景图片，这个是和用来显示两个Logo图片的GameLogoImageItem在同一层中
*/
class GameBackGroundItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT

public:
    GameBackGroundItem( QGraphicsItem *parent=0) ;
    ~GameBackGroundItem() ;

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    void setGameScene( GameGraphicsScene *gameScene,const NameAndImageHash &hash ) ;


private:

    GameGraphicsScene *m_Scene ;    //用来承载游戏场景的变量
    QPixmap backPixmap ;             //背景图片
};

#endif // GAMEBACKGROUNDITEM_H
