#ifndef GAMEMOVBACKGROUITEM_H
#define GAMEMOVBACKGROUITEM_H


#include <QObject>
#include <QGraphicsItem>
#include <QGraphicsPixmapItem>
#include <QPixmap>
#include <QPoint>
#include <QList>
#include <QKeyEvent>
#include <QTimer>
#include <QTime>

#include "globaldefines.h"
#include "GameGraphicsScene.h"

#include "GameSwimFishItem.h"
#include "GameSelectLevelItem.h"
#include "GameNumItem.h"
#include "GameAreaItem.h"
#include "GameForeGroundItem.h"
#include "GameGameOverItem.h"
#include "GameGamePauseItem.h"
/**************************************************************************
 *                        常量                                            *
 **************************************************************************/
//这个是设置的一个动态背景图片更新的时间间隔单位为毫秒
#define    MOVEBACKUPDATE_TIME       500

/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/

/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/
/*
这是一个动态背景的类，动态背景是有四张图片组成，通过计时器来切换背景图片达到动态的效果
在第三层显示，单独的一个类
*/
class GameMovBackGrouItem : public QObject, public QGraphicsPixmapItem
{
    Q_OBJECT
signals:

public:
    GameMovBackGrouItem(const QString &imageName ,QGraphicsItem *parent=0) ;
    ~GameMovBackGrouItem() ;

    //设置场景与获得存储在NameAndImageHash表中的图片名字与图片的值
    //同时获得在NameAndPointHash表中的坐标的值
    void setGameScene( GameGraphicsScene *gameScene,
          const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;

    /**这个是按下Esc键时返回到游戏首页的函数，在这里先处理掉第四层与第五层的所有Item**/
    //这个是删除第四层与第五层所有Item的函数
    void removeFourthAndFifthItemFun() ;
private:
    /*
    这个是定义的动态背景的状态的一个枚举类型
    First：表示的是显示第一张背景图片
    Second：表示的是显示第二张背景图片
    Third：表示当显示第三张背景图片
    Fourth：表示当显示第四张背景图片
    */
    enum MoveBackState { First = 0 , Second , Third ,Fourth } ;

    QString myImageName ;        //用来承载构造函数的imageName参数的
    GameGraphicsScene *m_Scene ;    //用来承载游戏场景的变量

    int pixWidth ;                  //这个是记录图片的宽与高的两个变量
    int pixHeight ;                 //注意这里记录的是一个状态的图片的宽与高，不是整张大图的宽与高
    QPixmap movBackPixmap ;      //动态背景的图片，其实就是一大张图
    //根据动态背景的状态得到这个状态下要显示的图片
    inline QPixmap getMoveBackPixmap( MoveBackState state ) ;
    MoveBackState nowState ;     //记录当前图片的状态的

    QTimer *timer ;             //计数器用于更新背景图片

    /****************************5条小鱼******************************/
    //小鱼是作为第3层的子Item加进来的
    GameSwimFishItem *firstLeftFish ;   //从左边出发的第一条小鱼
    GameSwimFishItem *firstRightFish ;  //从右边出发的第一条小鱼
    GameSwimFishItem *secondLeftFish ;  //从左边出发的第二条小鱼
    GameSwimFishItem *secondRightFish ; //从右边出发的第二条小鱼
    GameSwimFishItem *thirdLeftFish ;   //从左边出发的第三条小鱼

    //添加5条游动的小鱼
    void addSwimFishItem( const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash) ;

    inline int getRandomXCoord() ;      //得到小鱼随机的x坐标的值

    /****************************第四层Item******************************/
    GameNumItem *speedNum ;          //表示速度的值的图片
    GameNumItem *rowNum ;            //表示行数的值的图片
    GameNumItem *scoreNum ;          //表示分数的值的图片


    //添加表示速度，行数，得分的数字的图片
    void addAllGameNumItem( const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;

    GameSelectLevelItem *levelItem ;     //选择关卡的Item
    //添加选择关卡的Item
    void addGameSelectLevelItem( const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash) ;

    int nowLevelNum ;            //表示当前的level的数字
    //用来承载图片容器的变量
    NameAndImageHash m_nameImagehash ;
    GameAreaItem *areaItem ;     //表示游戏区域的Item
    //添加表示游戏区域的Item
    void addGameAreaItem( int levelNum ,const NameAndImageHash &nameImagehash ) ;


    /****************************第五层Item******************************/
    GameForeGroundItem *foreGroundItem ;      //前景图片的item
    //添加前景图片的item
    void addGameForeGroundItem( const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash) ;

    GameGameOverItem *gameOverItem ;         //游戏结束对话框的item
    //添加游戏结束对话框的item
    void addGameGameOverItem( const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;

    GameGamePauseItem *gamePauseItem ;       //游戏暂停对话框的item
    //添加游戏暂停对话框的item
    void addGameGamePauseItem( const NameAndImageHash &nameImagehash,const NameAndPointHash &namePointHash ) ;
private slots:
    void timeoutSlot( ) ;        //timeout()信号的槽函数
    //当用户选择好关卡之后，显示在速度栏里面
    void dealToDisNowLevel( int levelNum ) ;
    //这个是发送的endTimeLine结束的信号的槽函数
    void dealToDisAreaItem() ;

    /******************这是更新速度，消除的总行数的，以及得分的槽函数***************/
    //这个是更新消除的速度的槽函数
    void updateSpeedNumSlot( int speednum );
    //这个是更新消除的总行数的槽函数
    void updateNumRowsRemovedSlot( int rownum ) ;
    //这个是更新消除的用户分数的槽函数
    void updateScoreNumSlot( int scorenum ) ;

    //这个是游戏结束的槽函数
    void gameOverSlot() ;
    //这个是游戏重新开始的槽函数
    //在GameAreaItem类中还有一个重启的槽函数
    void gameRestartSlot() ;
    /*********************这个是为游戏暂停准备的槽函数*******************/
    //按下p键的暂停游戏的槽函数
    //在GameAreaItem类中还有一个暂停游戏的槽函数
    void pauseKeyDownSlot() ;

    /**********************这个是当游戏被停用时的发送的信号********************/
    //这个是当游戏被停用时的发送的信号
    //就是当鼠标点击电脑桌面其他位置时，就是我们平常所说的整个游戏软件失去焦点时。发送这个信号
    //在GameAreaItem类中还有一个同样的槽函数
    void gameDeactivateSlot() ;
protected:
    //void keyPressEvent ( QKeyEvent * e ) ;
    void mousePressEvent ( QGraphicsSceneMouseEvent * event ) ;
    void mouseReleaseEvent ( QGraphicsSceneMouseEvent * event ) ;
};

#endif // GAMEMOVBACKGROUITEM_H
