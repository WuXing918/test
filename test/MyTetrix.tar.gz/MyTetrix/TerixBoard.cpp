#include "TetrixBoard.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类TerixBoard实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： TerixBoard
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：level为用户选择的关数，根据这个关数来指定计时器跟新的时间间隔，
*         进而改变方块下降速度
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/


TerixBoard::TerixBoard(int level, const NameAndImageHash &nameImagehash)
    :isStarted(false),isPaused(false),isGameOver(false)
{
    //用当前时间的秒数进行喂种，这样每次起来时，就不会是同一个滑块啦！
    qsrand(QTime(0,0,0).secsTo(QTime::currentTime()));
    //承接用户指定的关数
    speedNum = level ;
    //初始话所有的图片相关的变量
    init_All_Pixmaps(nameImagehash) ;

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(timeoutSlot()));

    clearBoard();          //清除board上的所有方块

    /*
    首先随机得到一个方块，这个方块是在游戏开始时作为第一个出现的方块。
    注意这里是用的nextPiece而不是直接写的curPiece，这是为啦使得下面的统一，
    因为下面的curPiece都是要从nextPiece上得到。
    */
    nextPiece.setRandomShape();
    //开始游戏
    gameStart() ;
}



/***********************************************************************
* 函数名称： ~TerixBoard()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/

TerixBoard::~TerixBoard()
{

}


/***********************************************************************
* 函数名称： getGameAreaPixmap()
* 功能描述： 这个是对外的两个获得游戏区域的图片的接口函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
QPixmap TerixBoard::getGameAreaPixmap()
{
    return gameAreaPixmap ;
}

/***********************************************************************
* 函数名称： getNextPiecePixmap()
* 功能描述： 这个是对外的两个获得游戏区域的图片的接口函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
QPixmap TerixBoard::getNextPiecePixmap()
{
    return nextPiecePixmap ;
}


/***********************************************************************
* 函数名称： dropDownFun()
* 功能描述： 直接扔到最底部
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::dropDownFun()
{
    int newY = cur_Y_Coord ;
    //直接移动到可以到达的最底部
    while (newY > 0)
    {
        if (!tryMove(curPiece, cur_X_Coord, newY - 1))
        {
            break;
        }
        --newY;
    }
    //这个是当一个滑块落到最底部之后的处理函数
    pieceDroppedToBottom();
}

/***********************************************************************
* 函数名称： oneLineDownFun()
* 功能描述： 向下移动一行
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::oneLineDownFun()
{
    //尝试着向下移动一行，如果不能移动则是到达最底部
    if (!tryMove(curPiece, cur_X_Coord, cur_Y_Coord - 1))
    {
        //这个是当一个滑块落到最底部之后的处理函数
        pieceDroppedToBottom();
    }

}

/***********************************************************************
* 函数名称： moveToLeftFun()
* 功能描述： 向左移动
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::moveToLeftFun()
{
    tryMove(curPiece, cur_X_Coord - 1, cur_Y_Coord);
}

/***********************************************************************
* 函数名称： moveToRightFun()
* 功能描述： 向右移动
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::moveToRightFun()
{
    tryMove(curPiece, cur_X_Coord + 1, cur_Y_Coord);
}

/***********************************************************************
* 函数名称： rotateFun()
* 功能描述： 变形操作，每次逆时针旋转90度
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::rotateFun()
{
    bool result = tryMove(curPiece.rotatedRight(), cur_X_Coord, cur_Y_Coord) ;
    //如果变形失败，则调用微调变形函数
    if( !result )
    {
        //DEBUGP( "adjustForRotateFun" ) ;
        adjustForRotateFun() ;
    }
}


/***********************************************************************
* 函数名称： pauseKeyDownFun()
* 功能描述： 按下p键的暂停游戏的接口函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::pauseKeyDownFun()
{
    //暂停是要在游戏已经开始的状态下，否则没有用的
    if( isStarted )
    {
        //如果这个时候已经是暂停的则继续游戏
        if( isPaused )
        {
            //以原来的时间间隔来继续游戏
            timer->start( intervalTime );
        }
        else    //没有暂停则暂停游戏
        {
            timer->stop();
        }
        //改变游戏暂停的标志
        isPaused = !isPaused ;
    }

}
/***********************************************************************
* 函数名称： restartGame()
* 功能描述： 重新开始游戏
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明： 重新开始游戏时，那个游戏关卡选择的Item会降下来，重新选择关卡，之后才开始
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::restartGame()
{
    isGameOver = false ;       //改变游戏结束的标签

    //清空之前消除的总行数与总得分
    //在这里发送更新消除的总行数的信号
    emit updateNumRowsRemovedSignal( 0 );

    //在这里发送更新消除的总得分的信号
    emit updateScoreNumSignal( 0 );

    //因为重新开始是清空board数组啦的，在这里要更新显示
    emit updateGameAreaPixmapSignal() ;
}

/***********************************************************************
* 函数名称： gameDeactivateFun()
* 功能描述： 这个是当游戏不为当前活动窗口时的功能函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::gameDeactivateFun()
{
    //暂停是要在游戏已经开始的状态下，否则没有用的
    if( isStarted )
    {
        //如果没有暂停则暂停游戏
        if( !isPaused )
        {
            timer->stop();
        }
        //改变游戏暂停的标志
        isPaused = true ;
    }
}


/***********************************************************************
* 函数名称： getGamePauseStateFun()
* 功能描述： 得到游戏当前是否暂停的状态的函数接口
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
bool TerixBoard::getGamePauseStateFun()
{
    //DEBUGP( isPaused ) ;
    return isPaused ;
}

/***********************************************************************
* 函数名称： getGameGameOverStateFun()
* 功能描述： 得到游戏当前是否结束的状态的函数接口
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
bool TerixBoard::getGameGameOverStateFun()
{
    //DEBUGP( isGameOver ) ;
    return isGameOver ;
}
/***********************************************************************
* 函数名称： init_All_Pixmaps()
* 功能描述： 初始话所有的图片相关的变量
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明： 这里虽然只初始化啦一个图片变量，但是还是用啦一个函数，
*          以免以后要做其他扩展时方便。
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::init_All_Pixmaps(const NameAndImageHash &nameImagehash)
{
    //这里只是初始化八种不同方块对应的图片
    blankPixmap = QPixmap( PIECE_WIDTH,PIECE_HEIGHT ) ;
    //填充为透明色，使之为空白的
    blankPixmap.fill( Qt::transparent ) ;
    //加载7种方块的图片
    QImage *image = nameImagehash.value( BOX_BOX1 ) ;
    onePixmap = QPixmap::fromImage( *image ) ;
    image = nameImagehash.value( BOX_BOX2 ) ;
    twoPixmap = QPixmap::fromImage( *image ) ;
    image = nameImagehash.value( BOX_BOX3 ) ;
    threePixmap = QPixmap::fromImage( *image ) ;
    image = nameImagehash.value( BOX_BOX4 ) ;
    fourPixmap = QPixmap::fromImage( *image ) ;
    image = nameImagehash.value( BOX_BOX5 ) ;
    fivePixmap = QPixmap::fromImage( *image ) ;
    image = nameImagehash.value( BOX_BOX6 ) ;
    sixPixmap = QPixmap::fromImage( *image ) ;
    image = nameImagehash.value( BOX_BOX7 ) ;
    sevenPixmap = QPixmap::fromImage( *image ) ;

}
/***********************************************************************
* 函数名称： gameStart()
* 功能描述： 开始游戏
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::gameStart()
{
    /*
    这个是表示本来游戏已经就开始，现在处于暂停状态，这个时候再要开始则不会做出反应
    */
    if( isPaused )
    {
        return ;
    }

    isStarted = true ;    //改变状态
    isPaused = false ;
    isGameOver = false ;

    numRowsRemoved = 0 ;  //初始的时候消除的总行数默认为0
    //注意这两个得分的区别
    scoreNum = 0 ;        //得分的总数为0
    levelScoreNum = 0 ;   //这个是表示的在当前这个关中的得分

    clearBoard() ;        //清除board上的所有方块

    //根据关数设定其计数器的时间，也就是方块下降的间隔
    intervalTime = getIntervalTime( speedNum ) ;
    timer->start( intervalTime );

    createNewPiece() ;    //创建新的方块

}




/***********************************************************************
* 函数名称： gameOver()
* 功能描述： 游戏结束
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::gameOver()
{
    isGameOver = true ;
    isStarted = false ;   //改变游戏的状态标识
    timer->stop();        //停止计时器
    //这个是设置游戏区域的图片为灰色
    setGameAreaPixmapDisabled() ;
    //发送这个是发送的游戏结束的信号
    emit gameOverSignal() ;
}


/***********************************************************************
* 函数名称： setGameAreaPixmapDisabled()
* 功能描述： 这个是设置游戏区域的图片为灰色
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::setGameAreaPixmapDisabled()
{
    QIcon icon( gameAreaPixmap ) ;
    QSize size = gameAreaPixmap.size() ;
    //这个是通过处理得到灰色的图片
    gameAreaPixmap = icon.pixmap( size,QIcon::Disabled) ;
    //处理完则发送信号来更新显示
    emit updateGameAreaPixmapSignal() ;

}
/***********************************************************************
* 函数名称： createNewPiece()
* 功能描述： 创建新的方块
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
*        这里可以把底层的这个board看成是一个由一个个小方块组成的坐标系统
*        原点在左下角
*             y ^
*           	|
*        19     |
*        18	|
*        .	|
*        .	|
*        2	|
*        1	|
         0      |
*             --|------------------------------>
*                  0  1  2 ... ....   9       x
*        其中横坐标与纵坐标分别由 PIECE_NUM_IN_HORIZONTAL , PIECE_NUM_IN_VERTICAL 决定.
*        cur_X_Coord与cur_Y_Coord就是这个坐标系中的坐标值，之后方块就从这个坐标系统中移动
*
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::createNewPiece()
{
    /*
    把下一个即将出现的方块赋值给现在出现的方块，然后下一个再重新随机生成一个方块
    */
    curPiece = nextPiece;
    nextPiece.setRandomShape();
    //绘制下一个方块的图片
    drawNextPiecePixmap( ) ;

    //这个是给这个坐标值赋初始值，让每个新的方块都从游戏区域的中间位置下来。
    cur_X_Coord = PIECE_NUM_IN_HORIZONTAL / 2 - 1 ;
    cur_Y_Coord = PIECE_NUM_IN_VERTICAL - 1 + curPiece.minY() ;

    if ( !tryMove(curPiece, cur_X_Coord, cur_Y_Coord) )
    {
        //如果游戏已经开始，这个时候如果不能出来则表示游戏结束
        if( isStarted )
        {
            gameOver() ;      //游戏结束
        }
        else
        {
            //由于其不能试着向下移动，则设置其当前的方块的形状为空类型
            curPiece.setShape( NoShape );
            timer->stop();
            isStarted = false;
            DEBUGP( "Game Start Error !") ;
        }
    }
}

/***********************************************************************
* 函数名称： drawGameAreaPixmap()
* 功能描述： 这个是绘制游戏区域的图片的函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：由于这里都是直接在gameAreaPixmap图片画绘制，
*                所以纵坐标与横坐标都是哦从0开始的
************************************************************
*注意这里的图片跟nextPiecePixmap下一个方块的图片一样都是在绘制之前
*重新赋值一个新的画布，因为直接在以前的画布上绘制的话，之前绘制的方块图
*片也在上面，想通过擦除来恢复以前的状态不容易
*因为擦除也是一种绘制，所以要用周围没有被绘制过的区域来覆盖才可以恢复，
*这样就很麻烦，不如每次都一个新的画布，这样干净利落
************************************************************
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::drawGameAreaPixmap()
{
    /*
    这里是根据横轴方向的方块数与纵轴方向的方块数，
    以及小方块的宽与高来确定整个游戏区域的大小
    */
    gameAreaPixmap = QPixmap( PIECE_NUM_IN_HORIZONTAL*PIECE_WIDTH ,
                                  PIECE_NUM_IN_VERTICAL*PIECE_HEIGHT ) ;
    //用透明色填充游戏区域
    gameAreaPixmap.fill( Qt::transparent );

    /*这样绘制的结果直接在gameAreaPixmap上面。不用绘图事件*/
    QPainter painter( &gameAreaPixmap );

    //这个是画已经下降到底部的方块
    for ( int i = 0; i < PIECE_NUM_IN_VERTICAL ; ++i )
    {
        for (int j = 0; j < PIECE_NUM_IN_HORIZONTAL ; ++j)
        {
            TetrixShape shape = shapeAt(j, PIECE_NUM_IN_VERTICAL - i - 1);
            if (shape != NoShape)
            {
                /*
                由于这里都是直接在gameAreaPixmap图片画绘制，
                所以纵坐标与横坐标都是哦从0开始的
                */
                drawSquare(painter, j * PIECE_WIDTH, i * PIECE_HEIGHT, shape);
            }
        }

    }

    //这个是画正在下降的方块
    if (curPiece.shape() != NoShape)
    {
        for (int i = 0; i < 4; ++i)
        {
            int x = cur_X_Coord + curPiece.x(i);
            int y = cur_Y_Coord - curPiece.y(i);
            /*
            由于这里都是直接在gameAreaPixmap图片画绘制，
            所以纵坐标与横坐标都是哦从0开始的
            */
            /*注意这里的纵坐标的值是从上到下变小的，这个board坐标系的原点在左下角*/
            drawSquare(painter,  x * PIECE_WIDTH,
                       (PIECE_NUM_IN_VERTICAL - y - 1) * PIECE_HEIGHT,
                       curPiece.shape());
        }
    }
    //每次调用完这个函数则发送信号来更新显示
    emit updateGameAreaPixmapSignal();
}

/***********************************************************************
* 函数名称： drawNextPiecePixmap()
* 功能描述： 这个是绘制下一个方块的图片的函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::drawNextPiecePixmap( )
{
    /*
    根据每种方块的类型来确定其dx与dy。这个直接影响到图片的大小，
    故而不能跟GameAreaPixmap一样使用一个固定大小的图片来确定
    */
    int dx = nextPiece.maxX() - nextPiece.minX() + 1;
    int dy = nextPiece.maxY() - nextPiece.minY() + 1;

    nextPiecePixmap = QPixmap(dx * PIECE_WIDTH, dy * PIECE_HEIGHT );
    /*
    这里用透明色来填充，因为每个俄罗斯方块不是个标准的矩形，其他不必要的地方
    因为透明，看不到
    */
    nextPiecePixmap.fill( Qt::transparent );
    //这样声明可以直接绘制带pixmap上，不需要经过qt绘图事件的处理。
    QPainter painter(&nextPiecePixmap);
    //绘制pixmap
    for (int i = 0; i < 4; ++i)
    {
        /*
        注意这里的x与y是在根据上面的dx与dy确定的坐标
        */
        int x = nextPiece.x(i) - nextPiece.minX();
        int y = nextPiece.y(i) - nextPiece.minY();

        drawSquare(painter, x * PIECE_WIDTH, y * PIECE_HEIGHT,
                   nextPiece.shape());
    }
    //每次调用完这个函数则发送信号来更新显示
    emit updateNextPiecePixmapSignal() ;
}


/***********************************************************************
* 函数名称： drawSquare()
* 功能描述： 这个函数是绘制每一个小方块的函数，根据每一个小方块所属的类型
*          以及其坐标来绘制不同颜色的小方块
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::drawSquare(QPainter &painter, int x, int y, TetrixShape shape)
{
    /*
    这是定义的一个由8种不同的图片组成的一个数组，每种方块对应一种图片
    */
    static const QPixmap pixmapTable[8] = {
        blankPixmap,onePixmap,twoPixmap,threePixmap,
        fourPixmap,fivePixmap,sixPixmap,sevenPixmap,
    };
    QPixmap pixmap = pixmapTable[ int(shape) ] ;
    if( !pixmap.isNull() )
    {
        pixmap = pixmap.scaled( PIECE_WIDTH,PIECE_HEIGHT ) ;
        /*
        可以相应的在坐标上加上1，这样可以使每个方块不至于连在一起，
        这样给人看着爽些
        */
        QRect rect(x + 1,y+1,PIECE_WIDTH-1,PIECE_HEIGHT-1) ;
        painter.setPen(Qt::NoPen);
        painter.drawPixmap(rect,pixmap);
    }
}

/***********************************************************************
* 函数名称： getIntervalTime()
* 功能描述： 这个是根据不同的关数来设定的这个计时器的更新间隔时间的函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
int TerixBoard::getIntervalTime(int level)
{
    int gaptime = 0 ;
    //为啦安全起见，这里的关数首先进行判断是否是正常的，否则退出程序
    Q_ASSERT( level > 0 && level <= 10 ) ;

    switch( level )
    {
        case 1 :
            gaptime = 700 ;
            break ;
        case 2 :
            gaptime = 600 ;
            break ;
        case 3 :
            gaptime = 500 ;
            break ;
        case 4 :
            gaptime = 450 ;
            break ;
        case 5 :
            gaptime = 400 ;
            break ;
        case 6 :
            gaptime = 350 ;
            break ;
        case 7 :
            gaptime = 300 ;
            break ;
        case 8 :
            gaptime = 250 ;
            break ;
        case 9 :
            gaptime = 150 ;
            break ;
        case 10 :
            gaptime = 100 ;
            break ;
        default:
            break ;
    }

    return gaptime ;

}


/***********************************************************************
* 函数名称： tryMove()
* 功能描述： 这个是试着移动的函数，通过结果判断是否成功，如果成功则返回true，否则返回false，
*            成功则在游戏的画布上移动这个方块，否则不移动
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
bool TerixBoard::tryMove(const TetrixPiece &newPiece, int newX, int newY)
{
    for (int i = 0; i < 4; ++i)
    {
        /*
        这里只所以是加是因为上面所说的坐标原点在左下角，故x轴方向是加，y轴方向是减
        */
        int x = newX + newPiece.x(i);
        int y = newY - newPiece.y(i);

        if (x < 0 || x >= PIECE_NUM_IN_HORIZONTAL || y < 0 || y >= PIECE_NUM_IN_VERTICAL)
        {
            return false;
        }
        //接触到已经下降到底部的方块
        if (shapeAt(x, y) != NoShape)
        {
            return false;
        }

    }
    //因为有些方块要形变，之后就不是现在的这个啦，所以这里有个替换
    curPiece = newPiece ;

    cur_X_Coord = newX;
    cur_Y_Coord = newY;
    //因为经过上面的计算是可以移动的，所以在这里得重新绘制gameAreaPixmap
    drawGameAreaPixmap( ) ;

    return true;
}

/***********************************************************************
* 函数名称： tryMove()
* 功能描述： 因为在游戏区域左右两边的滑块不能变形，用这个函数做一个微调，让其变形成功
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明： 这里有些死循环，如果碰上问题会进入假死的状态
*在这里为啦安全起见加一个安全锁，当超过一定次数时，让其退出
*因为整个游戏区域只有一定的大小，超过一个限定的次数如5次，就不正常，
*再循环下去只会是死循环
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::adjustForRotateFun()
{
    //这个是为啦安全起见加的一个计数器。超过一定限度就安全退出
    //避免进入死循环中
    int counter_For_Safe = 0 ;
    //这里小于2是因为最左边两行可能都不能变形
    /*
    在最左边不能变形时，可以这样先把方块向右移动到刚好可以变形成功的位置，
    然后变形，之后移动到最最左边
    */
    if( cur_X_Coord < 2 )
    {
        while( !tryMove(curPiece.rotatedRight(), cur_X_Coord, cur_Y_Coord) )
        {
            //每次向右移动一列，至到变形成功
            moveToRightFun();     //向右移动一列
            SECURE_LOCK( counter_For_Safe ) ;
        }
        counter_For_Safe = 0 ;      //清零，重新开始计数。重上安全锁
        //变形完成之后移动最左边
        while( tryMove(curPiece, cur_X_Coord - 1, cur_Y_Coord) )
        {
            SECURE_LOCK( counter_For_Safe ) ;
        }
        counter_For_Safe = 0 ;      //清零，重新开始计数。重上安全锁
    }
    //这里大于于( PIECE_NUM_IN_HORIZONTAL - 3 )是因为最右边两行可能都不能变形
    /*
    在最右边不能变形时，可以这样先把方块向左移动到刚好可以变形成功的位置，
    然后变形，之后移动到最最右边
    */
    if( cur_X_Coord > ( PIECE_NUM_IN_HORIZONTAL - 3 ) )
    {
        while( !tryMove(curPiece.rotatedRight(), cur_X_Coord, cur_Y_Coord) )
        {
            //每次向左移动一列，至到变形成功
            moveToLeftFun();
            SECURE_LOCK( counter_For_Safe ) ;
        }
        counter_For_Safe = 0 ;      //清零，重新开始计数。重上安全锁
        //变形完成之后移动最右边
        while( tryMove(curPiece, cur_X_Coord + 1, cur_Y_Coord) )
        {
            SECURE_LOCK( counter_For_Safe ) ;
        }
        counter_For_Safe = 0 ;      //清零，重新开始计数。重上安全锁
    }

}
/***********************************************************************
* 函数名称： removeFullLines()
* 功能描述： 删除其中的满行
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明： 当一个俄罗斯方块落到最底部时，这里得记录如下两个数据，一个是这时有多少行已经是
*满行，另一个是记录当前满行的纵坐标，如果是多行满行时，这个时候记录最下面一行的纵坐标，
*用这个来确定爆炸特效的位置
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::removeFullLines()
{
    int numFullLines = 0;    //用来统计这一次的满行数

    IntList yCoordList ;     //这个是定义的一个整形的列表，用来统计满行的纵坐标值
    /*从上向下统计完全填满的行*/
    for ( int i = PIECE_NUM_IN_VERTICAL - 1; i >= 0; --i )
    {
        bool lineIsFull = true;
        for (int j = 0; j < PIECE_NUM_IN_HORIZONTAL; ++j)
        {
            //数每一横中的每一个方块位置，出现空格说明没有满一行
            if (shapeAt(j, i) == NoShape)
            {
                lineIsFull = false;
                break;
            }
        }
        if( lineIsFull )
        {
            numFullLines += 1 ;          //统计这次满行的行数
            yCoordList.append(i) ;    //用来记录满行的纵坐标的值
        }
    }
    //如果有满行，则进行之后的处理
    //这个时候yCoord的值就是最下面一个满行的坐标值，根据这个值来确定爆炸的位置
    if( numFullLines )
    {
        //根据满行数来统计消除的总行数
        computeNumRowsRemoved( numFullLines ) ;
        //根据满行数来统计总的得分，得分会有一个规则的按照得分规则进行统计
        computeScoreNum( numFullLines );

        //通过board坐标系中的y坐标的值，计算出在GameAreaItem中对应的坐标值
        //计算之后，发送信号通知显示爆炸特效
        getPosByPieceYCoord( yCoordList.last() ) ;

        //都处理完毕，现在删除满行
        foreach( int yCoord,yCoordList )
        {
            //吧满行上面的所有行都想下移动
            for( int k= yCoord;k<PIECE_NUM_IN_VERTICAL-1;k++)
            {
                for (int j = 0; j < PIECE_NUM_IN_HORIZONTAL; ++j)
                {
                    //直接把这个满行上面的一行移到下面来，就可以达到删除满行的效果
                    shapeAt(j, k ) = shapeAt(j, k + 1);
                }
            }
            //这个是把最上面的一行填充为空白
            for (int j = 0; j < PIECE_NUM_IN_HORIZONTAL; ++j)
            {
                shapeAt(j, PIECE_NUM_IN_VERTICAL - 1) = NoShape;
            }
        }

        //删除完毕，然后重新绘制游戏区域
        drawGameAreaPixmap();
    }

}

/***********************************************************************
* 函数名称： computeNumRowsRemoved()
* 功能描述： 根据满行数来统计消除的总行数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::computeNumRowsRemoved(int fullRowsNum)
{
    numRowsRemoved += fullRowsNum ;
    //在这里发送更新消除的总行数的信号
    emit updateNumRowsRemovedSignal( numRowsRemoved );
}

/***********************************************************************
* 函数名称： computeScoreNum()
* 功能描述： 根据满行数来统计总的得分，得分会有一个规则的按照得分规则进行统计
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：统计分数的时候有个规则，就是一次消除1行得10分，一次消除2行得30分，一次消除3行得50分，
*    一次消除4行得80分。一次最多也只能消除4行。
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::computeScoreNum(int fullRowsNum)
{
    switch( fullRowsNum )
    {
        case 1:
            scoreNum += 10 ;
            levelScoreNum  += 10 ;
            break ;
        case 2:
            scoreNum += 30 ;
            levelScoreNum  += 30 ;
            break ;
        case 3:
            scoreNum += 50 ;
            levelScoreNum  += 50 ;
            break ;
        case 4:
            scoreNum += 80 ;
            levelScoreNum  += 80 ;
            break ;
        default:
            DEBUGP( fullRowsNum ) ;
            break ;
    }
    //这个是根据目前的这关中得分情况来判断是否升级，提高方块下降的速度，增加难度
    changeSpeedNumByScore( levelScoreNum ) ;

    //在这里发送更新消除的总得分的信号
    emit updateScoreNumSignal( scoreNum );
}


/***********************************************************************
* 函数名称： changeSpeedNumByScore()
* 功能描述： 这个是根据目前的这关中得分情况来判断是否升级，提高方块下降的速度，增加难度
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::changeSpeedNumByScore(int levelscoreNum)
{
    int speedNumCopy = speedNum ;      //这个表示当前的速度的一个副本
    //当前的速度，也就是当前的关卡数
    switch( speedNumCopy )
    {
        case 1:
            if( levelscoreNum >= 800 )
            {
                speedNumCopy += 1 ;
            }
            break;
        case 2:
            if( levelscoreNum >= 1200 )
            {
                speedNumCopy += 1 ;
            }
            break;
        case 3:
            if( levelscoreNum >= 1500 )
            {
                speedNumCopy += 1 ;
            }
            break;
        case 4:
            if( levelscoreNum >= 1900 )
            {
                speedNumCopy += 1 ;
            }
            break;
        case 5:
            if( levelscoreNum >= 2300 )
            {
                speedNumCopy += 1 ;
            }
            break;
        case 6:
            if( levelscoreNum >= 2700 )
            {
                speedNumCopy += 1 ;
            }
            break;
        case 7:
            if( levelscoreNum >= 3100 )
            {
                speedNumCopy += 1 ;
            }
            break;
        case 8:
            if( levelscoreNum >= 3500 )
            {
                speedNumCopy += 1 ;
            }
            break;
        case 9:
            if( levelscoreNum >= 4000 )
            {
                speedNumCopy += 1 ;
            }
            break;
        case 10:
            //本来应该是升到第10关之后，如果分数再增加的话就通关啦，这里先留在这里之后再完成
            break;
        default:
            break;
    }
    //如果关数改变，则改变下降的速度
    if( speedNumCopy != speedNum )
    {
        speedNum = speedNumCopy ;
        levelScoreNum = 0 ;       //使之清零重新开始计数
        timer->stop();            //先关闭之前的
        intervalTime = getIntervalTime(  speedNum ) ;
        timer->start( intervalTime );    //重新开始计数，这个时候速度会加快
        //在这里发送更新当前速度的信号
        emit updateSpeedNumSignal( speedNumCopy );
    }
}

/***********************************************************************
* 函数名称： getPosByPieceYCoord()
* 功能描述： 通过board坐标系中的y坐标的值，计算出在GameAreaItem中对应的坐标值
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
************************************************************************
整个游戏区域是由20*10个小方块组成。高20个小方块，宽10个小方块。
通过这样组成一个坐标系。如下面所示：
              y ^
*           	|
*        19     |
*        18	|
*        .	|
*        .	|
*        2	|
*        1	|
         0      |
*             --|------------------------------>
                   0  1  2 ... ....   9       x
现在要做的就是以这个坐标系中的y轴的值来确定其在GameAreaItem中对应的坐标值
其实只需确定y轴的值就可以，x轴的值为0，因为爆炸特效是贴近边缘爆炸的
*************************************************************************
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::getPosByPieceYCoord(int yCoord)
{
    //用来记录在GameAreaItem中对应的坐标的y轴的值
    int yCoord_GameAreaItem ;
    //通过与最上面一行的坐标值之差的结果与每个小方块的高度的乘绩就是所要的结果
    //注意爆炸是要在满行的底部发生这样才逼真
    yCoord_GameAreaItem = (PIECE_NUM_IN_VERTICAL - yCoord ) * PIECE_HEIGHT ;

    //因为每次有满行时会调用这个函数，所以在这里调用消除满行时的产生爆炸声的信号
    emit crushAudioSoundSignal();

    //在这里通过一个信号发送给爆炸的Item进行爆炸处理
    //发送这个是发送显示爆炸特效的信号
    emit showBombEffectSignal( yCoord_GameAreaItem );
}
/***********************************************************************
* 函数名称： clearBoard()
* 功能描述： 初始化时清除board上的所有方块
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::clearBoard()
{
    for (int i = 0; i < PIECE_NUM_IN_HORIZONTAL * PIECE_NUM_IN_VERTICAL; ++i)
    {
        board[i] = NoShape;
    }
}


/***********************************************************************
* 函数名称： timeoutSlot()
* 功能描述： 这个是一个计时器时间结束信号的处理的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::timeoutSlot()
{
    //如果游戏没有结束
    if( !isGameOver )
    {
        //DEBUGP( "timeoutSlot" ) ;
        //如果到达时间间隔则下降一行
        oneLineDownFun() ;
    }
}


/***********************************************************************
* 函数名称： pieceDroppedToBottom()
* 功能描述： 这个是当一个滑块落到最底部之后的处理函数。注意这个最底部是接触到下面已经存
*          在的滑块或者到底游戏区域的最底部
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
void TerixBoard::pieceDroppedToBottom()
{
    /*
    在这里发送滑块落到最低点时撞击的声音的信号，这样就可以先是滑块撞击底部的声音，
    之后在是消除满行时爆炸的声音
    */
    emit fellAudioSoundSignal();
    //每次移到底部，则对board数组赋值
    //这时的cur_X_Coord和cur_Y_Coord是已经移动最底部的x与y轴的值
    for (int i = 0; i < 4; ++i)
    {
        int x = cur_X_Coord + curPiece.x(i);
        int y = cur_Y_Coord - curPiece.y(i);
        //在这里赋值，之后重新绘制的时候就可以通过这个数组来判断当前的方块类型啦
        //真他妈的经典阿
        shapeAt(x, y) = curPiece.shape();
    }
    //判断是否有满行，并进行计数，计数得分，然后消除满行，并且触发产死爆炸特效
    removeFullLines() ;

    //当前的滑块已经移动到最底部，所以就开始新的一个滑块。
    createNewPiece();
}
