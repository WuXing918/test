#ifndef GAMEGAMESOUND_H
#define GAMEGAMESOUND_H


#include <QObject>
#include <QString>
#include <QTimer>
#include <QSound>
#include <QSettings>

#include <phonon/audiooutput.h>
#include <phonon/seekslider.h>
#include <phonon/mediaobject.h>
#include <phonon/volumeslider.h>
#include <phonon/backendcapabilities.h>


#include "GameGraphicsScene.h"
#include "globaldefines.h"

/**************************************************************************
 *                        常量                                            *
 **************************************************************************/

//这个是水泡泡声音特效的响的时间间隔，单位为毫秒
#define       POPO_PLAY_TIME          15000
/**************************************************************************
 *                          宏定义                                         *
 **************************************************************************/


/**************************************************************************
 *                            数据类型                                     *
 **************************************************************************/


/**************************************************************************
 *                             类声明                                      *
 **************************************************************************/

/*
    这个是一个游戏声音的类，因为有游戏音乐与音效两种声音同时播放
    因为背景音乐是要在游戏开始的时候就一直重复的播放，而满行时的爆炸声和滑块撞击
    游戏区域底部的声音时要在特定的时间才播放，而水泡泡的声音是要一定的间隔时间重复
    播放一次。所以在这里分为3个播放设备
*/
class GameGameSound : public QObject
{
    Q_OBJECT

public:
    GameGameSound( int musicVolume , int audioVolume ) ;
    ~GameGameSound() ;

    /*
    这个是设置游戏场景，虽然这个类是一个游戏音乐与音效播放的类，属于一个数据处理的类，
    不会被当做Item放到游戏场景中，这里引入这个场景是为啦通过这个场景的通道来发送
    相关的信号与接收相应的槽函数，这样使得模块化更明显
    在后面把配置文件的指针也传进来，这样可以把播放的歌曲的资源的路经写进文件中去，
    这样可以是程序灵活些
    */
    void setGameSceneAndConfigF( GameGraphicsScene *gameScene,QSettings *configIni ) ;

private:
    int myMusicVolume ;              //用来承载构造函数中的音乐的音量大小的值
    int myAudioVolume ;              //用来承载构造函数中的音效的音量大小的值

    GameGraphicsScene *m_Scene ;     //用来承载游戏场景的变量
    QSettings *m_ConfigIni ;         //用来承载配置文件的指针的变量
    //这个是得到对应的因为文件的路经
    inline QString getSoundFilePathFromFile( QString groupname ,QString A_valueString ) ;

    //下面是一些游戏背景音乐的相关变量
    Phonon::MediaObject *musicObject;     //背景音乐播放的虚拟接口
    Phonon::AudioOutput *musicOutput;     //背景音乐播放的硬件设备接口
    Phonon::MediaSource musicSource;      //背景音乐播放的资源

    //这个是初始化游戏背景音乐的相关变量
    void initMusicSoundVar();

    //下面是一些游戏音效音乐的相关变量
    Phonon::MediaObject *audioObject;     //音效音乐播放的虚拟接口
    Phonon::AudioOutput *audioOutput;     //音效音乐播放的硬件设备接口

    //音效音乐播放的资源
    Phonon::MediaSource crushAudioSource;   //这个是消除满行时的爆炸声
    Phonon::MediaSource fellAudioSource;    //这个是当滑块落到底部时的撞击底部的声音
    //这个是初始化游戏音效音乐的相关变量
    void initAudioSoundVar();

    //这个是水泡泡的一个计时器，多长时间响一次水泡
    QTimer *timer ;
    //下面是一些游戏冒水泡泡的特效音乐的相关变量
    Phonon::MediaObject *popoaudioObject;     //音效音乐播放的虚拟接口
    Phonon::AudioOutput *popoaudioOutput;     //音效音乐播放的硬件设备接口
    Phonon::MediaSource popoAudioSource;    //这个是冒水泡泡的特效声音
    //这个是初始化游戏冒水泡泡的特效音乐的相关变量
    void initPopoAudioSoundVar();

    /**********这个是留出的两个接口，来设置音乐音量与音效音量的大小********/
    void setMusicVolume( int volume ) ;
    void setAudioVolume( int volume ) ;

private slots:
    //musicObject的aboutToFinish信号的槽函数
    void muObjAboutToFinishSlot() ;
    //timer的timeout信号的槽函数
    void timeoutSlot ();
    //这个是改变音乐与音效音量大小的槽函数
    void changeVolumeSlot( int musicVolume , int audioVolume ) ;

    /***************************************************************
      这下面是当滑块落到底部和消除满行时的声音特效的控制槽函数
    ***************************************************************/
    //这个是满行时产生爆炸声音的槽函数
    void crushAudioSoundSlot() ;
    //这个是当滑块落到最低点时撞击的声音的槽函数
    void fellAudioSoundSlot() ;
};

#endif // GAMEGAMESOUND_H
