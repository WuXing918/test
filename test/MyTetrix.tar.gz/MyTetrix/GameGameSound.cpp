#include "GameGameSound.h"


/**************************************************************************
 *                            常量                                        *
 **************************************************************************/



/**************************************************************************
 *                            宏                                          *
 **************************************************************************/


/**************************************************************************
 *                          数据类型                                       *
 **************************************************************************/



/**************************************************************************
 *                           全局变量                                      *
 **************************************************************************/



/**************************************************************************
 *                           局部函数原型                                  *
 **************************************************************************/

/**************************************************************************
 *                  类GameGameSound实现--公有部分                          *
 **************************************************************************/

/**************************************************************************
* 函数名称： GameGameSound
* 功能描述： 构造函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
GameGameSound::GameGameSound( int musicVolume, int audioVolume )
    :myMusicVolume(musicVolume),myAudioVolume(audioVolume)
{

}


/***********************************************************************
* 函数名称： ~GameGameSound()
* 功能描述： 析构函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
*************************************************************************/
GameGameSound::~GameGameSound()
{

}


/**************************************************************************
* 函数名称： setGameScene
* 功能描述： 这个是设置游戏场景，虽然这个类是一个游戏音乐与音效播放的类，属于一个数据处理的类，
*    不会被当做Item放到游戏场景中，这里引入这个场景是为啦通过这个场景的通道来发送
*    相关的信号与接收相应的槽函数，这样使得模块化更明显
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::setGameSceneAndConfigF(GameGraphicsScene *gameScene, QSettings *configIni)
{
    m_ConfigIni = configIni ;
    m_Scene = gameScene ;

    /********因为配置文件的指针在这里才初始化，所以初始化相关的文件要在这之后*******/
    //这个是初始化游戏背景音乐的相关变量,并且播放
    initMusicSoundVar() ;
    //这个是初始化游戏音效音乐的相关变量
    initAudioSoundVar() ;
    //这个是初始化游戏冒水泡泡的特效音乐的相关变量
    initPopoAudioSoundVar();

    //连接从场景中转发过来的满行时产生爆炸声音的的信号与槽函数
    connect(gameScene,SIGNAL(changeVolumeSignal(int,int)),this,SLOT(changeVolumeSlot(int,int)));
    //连接从场景中转发过来的满行时产生爆炸声音的信号与槽函数
    connect(gameScene,SIGNAL(crushAudioSoundSignal()),this,SLOT(crushAudioSoundSlot()));
    //连接从场景中转发过来的当滑块落到最低点时撞击的声音的信号与槽函数
    connect(gameScene,SIGNAL(fellAudioSoundSignal()),this,SLOT(fellAudioSoundSlot()));


}


/**************************************************************************
* 函数名称： getSoundFilePathFromFile
* 功能描述： 这个是得到对应的因为文件的路经
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
inline QString GameGameSound::getSoundFilePathFromFile(QString groupname, QString A_valueString)
{
    m_ConfigIni->beginGroup( groupname );
    m_ConfigIni->setIniCodec( "UTF-8" );
    QString filePath = m_ConfigIni->value( A_valueString ).toString() ;
    m_ConfigIni->endGroup();
    return filePath ;
}
/**************************************************************************
* 函数名称： initMusicSoundVar
* 功能描述： 这个是初始化游戏背景音乐的相关变量
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明： 这个背景音乐是要一直的循环播放
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::initMusicSoundVar()
{
    musicObject = new Phonon::MediaObject( this ) ;
    musicOutput = new Phonon::AudioOutput(Phonon::MusicCategory, this);

    QString musicPath = getSoundFilePathFromFile( GROUPNAME_SOUND,SOUND_MUSIC );
    //DEBUGP( musicPath ) ;
    musicSource = Phonon::MediaSource( musicPath ) ;

    //设置其当前的资源文件
    musicObject->setCurrentSource( musicSource );
    //连接musicObject的aboutToFinish信号与槽函数
    connect(musicObject,SIGNAL(aboutToFinish()),this,SLOT(muObjAboutToFinishSlot()));
    //连接播放的接口与硬件设备
    Phonon::createPath(musicObject, musicOutput);
    //DEBUGP( (qreal)myMusicVolume/(qreal)100 ) ;
    //设置背景音乐的播放的音量，注意这个音量值要转换为0.0到1.0的浮点数
    musicOutput->setVolume( (qreal)myMusicVolume/(qreal)100 );

    musicObject->play();

}

/**************************************************************************
* 函数名称： initAudioSoundVar
* 功能描述： 这个是初始化游戏音效音乐的相关变量
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::initAudioSoundVar()
{
    audioObject = new Phonon::MediaObject( this ) ;
    audioOutput = new Phonon::AudioOutput(Phonon::MusicCategory, this);
    QString crushPath = getSoundFilePathFromFile( GROUPNAME_SOUND,SOUND_CRUSHAUDIO );
    //DEBUGP( crushPath ) ;
    crushAudioSource = Phonon::MediaSource( crushPath ) ;
    QString fellPath = getSoundFilePathFromFile( GROUPNAME_SOUND,SOUND_FELLAUDIO );
    //DEBUGP( fellPath ) ;
    fellAudioSource = Phonon::MediaSource( fellPath ) ;

    //audioObject->setCurrentSource( crushAudioSource );
    //连接播放的接口与硬件设备
    Phonon::createPath(audioObject, audioOutput);
    //DEBUGP( (qreal)myAudioVolume/(qreal)100 ) ;
    //设置游戏音效音乐的播放的音量，注意这个音量值要转换为0.0到1.0的浮点数
    audioOutput->setVolume( (qreal)myAudioVolume/(qreal)100 );

}

/**************************************************************************
* 函数名称： initPopoAudioSoundVar
* 功能描述： 这个是初始化游戏冒水泡泡的特效音乐的相关变量
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::initPopoAudioSoundVar()
{
    popoaudioObject = new Phonon::MediaObject( this ) ;
    popoaudioOutput = new Phonon::AudioOutput(Phonon::MusicCategory, this);

    QString popoPath = getSoundFilePathFromFile( GROUPNAME_SOUND,SOUND_POPOAUDIO );
    //DEBUGP( popoPath ) ;
    popoAudioSource = Phonon::MediaSource( popoPath ) ;

    popoaudioObject->setCurrentSource( popoAudioSource );
    //连接播放的接口与硬件设备
    Phonon::createPath(popoaudioObject, popoaudioOutput);
    //这个的音量大小就是由游戏音效音乐的大小控制
    //设置游戏音效音乐的播放的音量，注意这个音量值要转换为0.0到1.0的浮点数
    //DEBUGP( (qreal)myAudioVolume/(qreal)100 ) ;
    popoaudioOutput->setVolume( (qreal)myAudioVolume/(qreal)100 );

    timer = new QTimer( this ) ;
    connect(timer,SIGNAL(timeout()),this,SLOT(timeoutSlot())) ;
    timer->start( POPO_PLAY_TIME );
}

/**************************************************************************
* 函数名称： setMusicVolume
* 功能描述： 这个是留出的两个接口，来设置音乐音量与音效音量的大小
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::setMusicVolume(int volume)
{
    myMusicVolume = volume ;
    //设置背景音乐的播放的音量，注意这个音量值要转换为0.0到1.0的浮点数
    musicOutput->setVolume( (qreal)myMusicVolume/(qreal)100 );
}

/**************************************************************************
* 函数名称： setAudioVolume
* 功能描述： 这个是留出的两个接口，来设置音乐音量与音效音量的大小
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::setAudioVolume(int volume)
{
    myAudioVolume = volume ;
    //设置游戏音效音乐的播放的音量，注意这个音量值要转换为0.0到1.0的浮点数
    audioOutput->setVolume( (qreal)myAudioVolume/(qreal)100 );
    popoaudioOutput->setVolume( (qreal)myAudioVolume/(qreal)100 );
}
/**************************************************************************
* 函数名称： muObjAboutToFinishSlot
* 功能描述： musicObject的aboutToFinish信号的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::muObjAboutToFinishSlot()
{
    //把当前的游戏背景的音乐文件作为资源重新加载进去，这样可以让其重复播放背景音乐
    musicObject->enqueue( musicSource );
}

/**************************************************************************
* 函数名称： timeoutSlot
* 功能描述： timer的timeout信号的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::timeoutSlot()
{
    //DEBUGP( "timeoutSlot" )
    popoaudioObject->play();
}

/**************************************************************************
* 函数名称： changeVolumeSlot
* 功能描述： 这个是改变音乐与音效音量大小的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::changeVolumeSlot(int musicVolume, int audioVolume)
{
    setMusicVolume( musicVolume );
    setAudioVolume( audioVolume );
}

/**************************************************************************
* 函数名称： crushAudioSoundSlot
* 功能描述： 这个是满行时产生爆炸声音的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::crushAudioSoundSlot()
{
    //DEBUGP( "crushAudioSoundSlot" ) ;
    //如果其正在播放音乐文件的话
    if( audioObject->state() == Phonon::PlayingState )
    {
        audioObject->stop();
    }
    else
    {
        audioObject->setCurrentSource( crushAudioSource );
        audioObject->play();
    }

}

/**************************************************************************
* 函数名称： fellAudioSoundSlot
* 功能描述： 这个是当滑块落到最低点时撞击的声音的槽函数
* 访问的表：
* 修改的表：
* 输入参数：
* 输出参数：
* 返 回 值：
* 其它说明：
* 修改日期    版本号     修改人	     修改内容
* -----------------------------------------------
*
**************************************************************************/
void GameGameSound::fellAudioSoundSlot()
{
    //如果其正在播放音乐文件的话
    if( audioObject->state() == Phonon::PlayingState )
    {
        audioObject->stop();
    }
    else
    {
        audioObject->setCurrentSource( fellAudioSource );
        //DEBUGP( "fellAudioSoundSlot" ) ;
        audioObject->play();
    }
}
